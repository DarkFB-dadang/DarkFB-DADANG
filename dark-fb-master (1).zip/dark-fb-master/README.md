# Dark-fb
tanpa lisensi

v1.6 <br>

pkg install python2<br>
pkg install git<Br>
git clone https://github.com/ZeDDParker/dark-fb<Br>
cd dark-fb<br>
python2 install.py<br>
<br>
<img src="https://raw.githubusercontent.com/rezadkim/dark-fb/master/Screenshot_2019-05-08-19-47-56.png">
